package com.wildcodeschool.myProject2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.server.ResponseStatusException;




// Kopie aus der Spring02 Quest
@Controller
@SpringBootApplication

public class MyProject2Application {

    public static void main(String[] args) {
        SpringApplication.run(MyProject2Application.class, args);
    }

    // @GetMapping("/hello")
    // @ResponseBody
    // public String hello() {
    //    return "Hello World!";
    // }
	

    @RequestMapping("/doctor/{id}")
    @ResponseBody
    public String doctor(@PathVariable int id) {
    //   return String.format("Hello %s", id);


    if(id==8 ||id ==7|| id ==6||id==5||id==4||id==3||id==2||id==1){
        throw new ResponseStatusException(HttpStatus.SEE_OTHER, "see another number");
   
    }

    if (id==9){
        return "{'Number :' " +  id + ", " + "'Christopher Eccleston'}";
    }
    
    if (id==10){
            return "{'Number :' " +  id + ", " + "'David Tennat'}";
    }
    
    if (id==11){
                return "{'Number :' " +  id + ", " + "'Matt Smith'}";
    }
    
    if (id==12){
                return "{'Number :' " +  id + ", " + "'Peter Capaldi'}";
    }

    if (id==13){
                return "{'Number :' " +  id + ", " + "'Jodie Whittaker'}";
    }
    
    else{
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Impossible to retrieve the incarnation number <incarnation number>");
        } 


    // aus der Quest: In the case of our StackOverflow question page for example, this could look like this. If id is zero, it is useless to continue on to return Question.getById(id);, 
    // so we make the program generate an error - throw an exception - before it reaches this line:
    
    // Aufruf mit http://localhost:8080/doctor/id nummer

    }
}
